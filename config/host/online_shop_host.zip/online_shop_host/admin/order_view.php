<?php
require_once __DIR__ . '/../includes/functions.php'; require_admin();
$id=max(1,(int)($_GET['id'] ?? $_POST['id'] ?? 0));
$allowedStatus=['Pending','Processing','Shipped','Delivered','Cancelled']; $allowedPayment=['Pending','Paid','Failed','Refunded'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); $orderStatus=$_POST['order_status'] ?? ''; $paymentStatus=$_POST['payment_status'] ?? '';
    $beforeStmt=$pdo->prepare('SELECT user_id,order_status FROM orders WHERE order_id=? LIMIT 1');$beforeStmt->execute([$id]);$beforeOrder=$beforeStmt->fetch();
    $beforePayStmt=$pdo->prepare('SELECT payment_status FROM payments WHERE order_id=? ORDER BY payment_id DESC LIMIT 1');$beforePayStmt->execute([$id]);$beforePayment=$beforePayStmt->fetchColumn() ?: 'Pending';
    if(!$beforeOrder){flash('error','Order not found.');redirect('admin/orders.php');}
    $targetUserId=(int)$beforeOrder['user_id']; $actorId=(int)$_SESSION['user']['user_id'];
    if(in_array($orderStatus,$allowedStatus,true)){
        $stmt=$pdo->prepare('UPDATE orders SET order_status=? WHERE order_id=?');$stmt->execute([$orderStatus,$id]);
        if($orderStatus!==$beforeOrder['order_status']) log_user_activity($pdo,$targetUserId,'order_status_changed','Order #' . $id . ' status changed from ' . $beforeOrder['order_status'] . ' to ' . $orderStatus . '.',['order_id'=>$id,'from'=>$beforeOrder['order_status'],'to'=>$orderStatus],$actorId);
    }
    if(in_array($paymentStatus,$allowedPayment,true)){
        $stmt=$pdo->prepare('UPDATE payments SET payment_status=? WHERE order_id=?');$stmt->execute([$paymentStatus,$id]);
        if($paymentStatus!==$beforePayment) log_user_activity($pdo,$targetUserId,'payment_status_changed','Order #' . $id . ' payment status changed from ' . $beforePayment . ' to ' . $paymentStatus . '.',['order_id'=>$id,'from'=>$beforePayment,'to'=>$paymentStatus],$actorId);
    }
    flash('success','Order updated.'); redirect('admin/order_view.php?id='.$id);
}
$stmt=$pdo->prepare('SELECT o.*,u.full_name,u.email,u.phone FROM orders o JOIN users u ON u.user_id=o.user_id WHERE o.order_id=?');$stmt->execute([$id]);$order=$stmt->fetch();if(!$order){flash('error','Order not found.');redirect('admin/orders.php');}
$itemsStmt=$pdo->prepare('SELECT oi.*,p.product_name,p.image FROM order_items oi LEFT JOIN products p ON p.product_id=oi.product_id WHERE oi.order_id=?');$itemsStmt->execute([$id]);$items=$itemsStmt->fetchAll();
$payStmt=$pdo->prepare('SELECT * FROM payments WHERE order_id=? ORDER BY payment_id DESC LIMIT 1');$payStmt->execute([$id]);$payment=$payStmt->fetch();
$orderRate=order_rate($order); $orderUsd=order_usd_amount($order);
$adminPageTitle='Order #'.$id; require __DIR__ . '/includes/admin_header.php';
?>
<div class="admin-toolbar"><div><span class="eyebrow">Order management</span><h1>Order #<?= $id ?></h1><p class="muted"><?= e(date('d M Y, h:i A',strtotime($order['order_date']))) ?></p></div><a class="btn btn-ghost" href="<?= url('admin/orders.php') ?>">← Orders</a></div>
<div class="admin-grid-2"><div class="admin-card"><h2>Items</h2><div class="table-wrap"><table class="data-table"><thead><tr><th>Product</th><th>Qty</th><th>Unit price</th><th>Subtotal</th></tr></thead><tbody><?php foreach($items as $i): $unitUsd=$orderRate?round((float)$i['unit_price']*$orderRate,2):null; $subUsd=$orderRate?round((float)$i['subtotal']*$orderRate,2):null; ?><tr><td><div style="display:flex;align-items:center;gap:10px"><img class="product-mini" src="<?= e(product_image($i['image'])) ?>"><strong><?= e($i['product_name'] ?: 'Deleted product') ?></strong></div></td><td><?= (int)$i['quantity'] ?></td><td><?= dual_money($i['unit_price'],$unitUsd,$orderRate,false) ?></td><td><?= dual_money($i['subtotal'],$subUsd,$orderRate,false) ?></td></tr><?php endforeach; ?></tbody></table></div><h3>Shipping address</h3><p class="muted"><?= nl2br(e($order['shipping_address'])) ?></p><h3>Customer</h3><p><?= e($order['full_name']) ?><br><span class="muted"><?= e($order['email']) ?><?= $order['phone']?'<br>'.e($order['phone']):'' ?></span></p></div>
<div class="admin-card"><h2>Update order</h2><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>"><div class="form-group"><label>Order status</label><select class="form-control" name="order_status"><?php foreach($allowedStatus as $s): ?><option <?= $order['order_status']===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div><div class="form-group" style="margin-top:14px"><label>Payment status</label><select class="form-control" name="payment_status"><?php foreach($allowedPayment as $s): ?><option <?= ($payment['payment_status'] ?? 'Pending')===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></div><div class="summary-row total"><span>Total</span><span><?= dual_money($order['total_amount'],$orderUsd,$orderRate,false) ?></span></div><?php if($orderRate): ?><div class="currency-checkout-note"><strong>Purchase-time exchange rate</strong><span>€1 = <?= usd_rate($orderRate) ?></span><small>Locked to this order; current-rate changes do not affect it.</small></div><?php endif; ?><div class="form-actions"><button class="btn btn-primary btn-block">Save update</button></div></form></div></div>
<?php require __DIR__ . '/includes/admin_footer.php'; ?>
